<div class="form-group">
	<label for="" class="col-sm-2 control-label">关键词</label>
	<div class="col-sm-10">
		<input type="text" class="form-control" name="keyword" value="{{$oldData ?$oldData->keyword()->keyword :''}}">
	</div>
</div>