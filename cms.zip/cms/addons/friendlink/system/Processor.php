<?php
namespace addons\friendlink\system;
use module\HdProcessor;

/**
 * 微信处理器
 * Class Processor
 *
 * @package addons\friendlink\system
 */
class Processor extends HdProcessor
{
	/**
	 * @param $bc_id   文章表的主键id/回复表的主键id
	 */
	public function handler($bc_id){

	}
}