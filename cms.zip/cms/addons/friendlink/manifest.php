<?php
return array (
  'csrf_token' => '2e7ebfdb30e7f41dac24b5025535bd9c',
  'name' => 'friendlink',
  'title' => '友情链接',
  'description' => '友情链接',
  'preview' => 'attachment/2017/12/28/2017/12/28/47581514421279.jpg',
);
?>